package com.trueonlinetech.truechat
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
