
import 'package:flutter/material.dart';

void main() => runApp(const TrueChatApp());

class TrueChatApp extends StatelessWidget {
  const TrueChatApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TrueChat',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF1769E0)),
      home: const SplashPage(),
    );
  }
}

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override State<SplashPage> createState()=>_SplashPageState();
}
class _SplashPageState extends State<SplashPage>{
  @override void initState(){super.initState(); Future.delayed(const Duration(seconds:2),()=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const LoginPage())));}
  @override Widget build(BuildContext c)=>Scaffold(body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    CircleAvatar(radius:58,backgroundColor:const Color(0xFF1769E0),child:const Icon(Icons.chat_bubble_rounded,size:60,color:Colors.white)),
    const SizedBox(height:18),const Text('TrueChat',style:TextStyle(fontSize:34,fontWeight:FontWeight.bold)),
    const SizedBox(height:6),const Text('Connect • Create • Trade • Work'),
  ])));
}

class LoginPage extends StatelessWidget{
  const LoginPage({super.key});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('TrueChat')),body:Padding(padding:const EdgeInsets.all(24),child:Column(children:[
    const SizedBox(height:30),const Text('Welcome back',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
    const SizedBox(height:24),const TextField(decoration:InputDecoration(labelText:'Email / phone / username',border:OutlineInputBorder())),
    const SizedBox(height:14),const TextField(obscureText:true,decoration:InputDecoration(labelText:'Password',border:OutlineInputBorder())),
    const SizedBox(height:20),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>Navigator.pushReplacement(c,MaterialPageRoute(builder:(_)=>const HomePage())),child:const Text('Login'))),
    TextButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const RegisterPage())),child:const Text('Create account')),
  ])));
}
class RegisterPage extends StatelessWidget{
  const RegisterPage({super.key});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Create account')),body:ListView(padding:const EdgeInsets.all(24),children:[
    const TextField(decoration:InputDecoration(labelText:'Full name',border:OutlineInputBorder())),const SizedBox(height:12),
    const TextField(decoration:InputDecoration(labelText:'Username',border:OutlineInputBorder())),const SizedBox(height:12),
    const TextField(decoration:InputDecoration(labelText:'Email / phone',border:OutlineInputBorder())),const SizedBox(height:12),
    const TextField(obscureText:true,decoration:InputDecoration(labelText:'Password',border:OutlineInputBorder())),const SizedBox(height:20),
    FilledButton(onPressed:()=>Navigator.pushAndRemoveUntil(c,MaterialPageRoute(builder:(_)=>const HomePage()),(_)=>false),child:const Text('Register')),
  ]));
}

class HomePage extends StatefulWidget{const HomePage({super.key});@override State<HomePage> createState()=>_HomePageState();}
class _HomePageState extends State<HomePage>{
 int i=0;
 final pages=const [FeedPage(),ChatPage(),ReelsPage(),TruePayPage(),ProfilePage()];
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('TrueChat'),actions:[IconButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const SearchPage())),icon:const Icon(Icons.search)),IconButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const NotificationsPage())),icon:const Icon(Icons.notifications_none))]),body:pages[i],
 bottomNavigationBar:NavigationBar(selectedIndex:i,onDestinationSelected:(v)=>setState(()=>i=v),destinations:const [
 NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
 NavigationDestination(icon:Icon(Icons.chat_outlined),selectedIcon:Icon(Icons.chat),label:'Chats'),
 NavigationDestination(icon:Icon(Icons.play_circle_outline),selectedIcon:Icon(Icons.play_circle),label:'Reels'),
 NavigationDestination(icon:Icon(Icons.account_balance_wallet_outlined),selectedIcon:Icon(Icons.account_balance_wallet),label:'TruePay'),
 NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile'),
 ]));
}
class FeedPage extends StatelessWidget{const FeedPage({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(12),children:[
 Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:const Text('Welcome to TrueChat'),subtitle:const Text('Personal & Business in one platform'),trailing:const Icon(Icons.verified))),
 const SizedBox(height:8),const Card(child:ListTile(leading:Icon(Icons.work_outline),title:Text('TrueJobs'),subtitle:Text('Find verified online opportunities'))),
 const Card(child:ListTile(leading:Icon(Icons.storefront_outlined),title:Text('TrueMarket'),subtitle:Text('Discover products and businesses'))),
 const Card(child:ListTile(leading:Icon(Icons.auto_awesome),title:Text('TrueAI'),subtitle:Text('Smart tools for creators and businesses'))),
 ]);}
class ChatPage extends StatelessWidget{const ChatPage({super.key});@override Widget build(BuildContext c)=>ListView(children:[
  ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:const Text('Demo User'),subtitle:const Text('Welcome to TrueChat'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const ConversationPage()))),
  const ListTile(leading:CircleAvatar(child:Icon(Icons.business)),title:Text('True Online Technologies'),subtitle:Text('Business account • Verified')),
 ]);}
class ConversationPage extends StatefulWidget{const ConversationPage({super.key});@override State<ConversationPage> createState()=>_ConversationPageState();}
class _ConversationPageState extends State<ConversationPage>{final ctrl=TextEditingController();final msgs=<String>['Welcome to TrueChat 👋'];@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Demo User')),body:Column(children:[Expanded(child:ListView.builder(itemCount:msgs.length,itemBuilder:(_,i)=>Align(alignment:i%2==0?Alignment.centerLeft:Alignment.centerRight,child:Container(margin:const EdgeInsets.all(8),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:i%2==0?Colors.grey.shade200:Theme.of(c).colorScheme.primaryContainer,borderRadius:BorderRadius.circular(16)),child:Text(msgs[i]))))),Padding(padding:const EdgeInsets.all(8),child:Row(children:[Expanded(child:TextField(controller:ctrl,decoration:const InputDecoration(hintText:'Message...',border:OutlineInputBorder()))),IconButton(onPressed:(){if(ctrl.text.trim().isNotEmpty){setState(()=>msgs.add(ctrl.text.trim()));ctrl.clear();}},icon:const Icon(Icons.send))]))]));}
class ReelsPage extends StatelessWidget{const ReelsPage({super.key});@override Widget build(BuildContext c)=>const Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.play_circle,size:80),Text('TrueChat Reels',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text('Short videos • creators • businesses')]);}
class TruePayPage extends StatelessWidget{const TruePayPage({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('TruePay Wallet'),const SizedBox(height:8),const Text('₦ 0.00',style:TextStyle(fontSize:34,fontWeight:FontWeight.bold)),const Text('Demo balance'),const SizedBox(height:18),Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_b(Icons.send,'Send'),_b(Icons.call_received,'Receive'),_b(Icons.add_card,'Fund')])])),),const ListTile(title:Text('Transactions'),subtitle:Text('No transactions yet'))];static Widget _b(IconData i,String t)=>Column(children:[CircleAvatar(child:Icon(i)),const SizedBox(height:4),Text(t)]);}
class ProfilePage extends StatelessWidget{const ProfilePage({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const CircleAvatar(radius:45,child:Icon(Icons.person,size:50)),const SizedBox(height:12),const Center(child:Text('Your TrueChat Profile',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold))),const Center(child:Text('@username • Personal Account')),const SizedBox(height:20),Card(child:Column(children:[ListTile(leading:const Icon(Icons.verified),title:const Text('Verification & badges'),trailing:const Icon(Icons.chevron_right)),ListTile(leading:const Icon(Icons.business),title:const Text('Business account'),trailing:const Icon(Icons.chevron_right)),ListTile(leading:const Icon(Icons.work),title:const Text('TrueJobs'),trailing:const Icon(Icons.chevron_right)),ListTile(leading:const Icon(Icons.store),title:const Text('TrueMarket'),trailing:const Icon(Icons.chevron_right)),ListTile(leading:const Icon(Icons.settings),title:const Text('Settings'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const SettingsPage())),trailing:const Icon(Icons.chevron_right))]))]);}
class SearchPage extends StatelessWidget{const SearchPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Search')),body:const Padding(padding:EdgeInsets.all(16),child:TextField(decoration:InputDecoration(hintText:'Username, number, email or TrueChat ID',prefixIcon:Icon(Icons.search),border:OutlineInputBorder()))));}
class NotificationsPage extends StatelessWidget{const NotificationsPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Notifications')),body:const Center(child:Text('No new notifications')));}
class SettingsPage extends StatelessWidget{const SettingsPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Settings')),body:ListView(children:const[SwitchListTile(value:true,onChanged:null,title:Text('Notifications')),ListTile(title:Text('Privacy & security'),trailing:Icon(Icons.chevron_right)),ListTile(title:Text('Language'),subtitle:Text('English')),ListTile(title:Text('About TrueChat'),subtitle:Text('Demo v1'))]));}
