# TrueChat Demo v2
Flutter Android demo for TrueChat. Includes Splash, Login, Register, Home, Chats, Reels, TruePay demo, Profile, Search, Notifications and Settings.

This is a UI/demo build. Real messaging, payments, identity verification, jobs and marketplace backend are not connected yet.
